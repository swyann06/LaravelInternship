<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showRegisterForm()
    {
        return view('register');
    }

    public function register(Request $request)
    {
        $avatar = $this->getDefaultAvatar($request->gender);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'gender' => $request->gender,
            'avatar' => $avatar,
            'role' => 'user', 
        ]);

        return redirect()->route('register.form')->with('success', 'Registration successful!');
    }

    private function getDefaultAvatar($gender)
    {
        if ($gender === 'male') {
            return 'storage/avatar/male.jpg';
        }

        return 'storage/avatar/female.jpg';
    }





    public function index()
    {
        $this->authorizeSuperAdmin();

        $users = User::with('role')->get();
        $roles = Role::all();

        return view('admin.users', compact('users', 'roles'));
    }

    public function updateRole(Request $request, User $user)
    {
        $this->authorizeSuperAdmin();

        $request->validate([
            'role_id' => 'required|exists:roles,id',
        ]);

        $newRole = Role::findOrFail($request->role_id);

        if ($newRole->name === 'superadmin') {
            $exists = User::whereHas('role', function ($q) {
                $q->where('name', 'superadmin');
            })->where('id', '!=', $user->id)->exists();

            if ($exists) {
                return back()->with('error', 'Superadmin already exists.');
            }
        }

        if ($user->id === auth()->id() && $newRole->name !== 'superadmin') {
            return back()->with('error', 'You cannot remove your own superadmin role.');
        }

        $user->role_id = $request->role_id;
        $user->save();

        return back()->with('success', 'Role updated successfully.');
    }

    private function authorizeSuperAdmin()
    {
        if (!auth()->check() || !auth()->user()->isSuperAdmin()) {
            abort(403);
        }
    }
    
}