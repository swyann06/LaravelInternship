<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class EditAvatarController extends Controller
{
    public function edit()
    {
        $user = Auth::user();
        return view('editAvatar', compact('user'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $user = Auth::user();

        if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
            Storage::disk('public')->delete($user->avatar);
        }

        $path = $request->file('avatar')->store('currentAvatar', 'public');

        $user->avatar = $path;
        $user->save();

        return redirect()->route('avatar.edit')->with('success', 'Avatar updated!');
    }
}
