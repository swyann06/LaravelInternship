<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\PostImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $posts = Post::with('images')->latest()->get();
        return view('posts.index', compact('posts'));
    }

    public function store(Request $request)
    {
        $post = Post::create([
            'user_id' => auth()->id(),
        ]);

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $path = $file->store('posts', 'public');

                PostImage::create([
                    'post_id' => $post->id,
                    'url'     => $path,
                ]);
            }
        }

        return redirect()->back()->with('success', 'Post created successfully!');
    }

    // app/Http/Controllers/PostController.php

public function edit(Post $post)
{
    $this->authorize('update', $post);

    return view('posts.edit', compact('post'));
}

public function update(Request $request, Post $post)
{
    $this->authorize('update', $post);

    if ($request->hasFile('images')) {
        foreach ($request->file('images') as $file) {
            $path = $file->store('posts', 'public');

            \App\Models\PostImage::create([
                'post_id' => $post->id,
                'url' => $path,
            ]);
        }
    }

    return redirect()->route('posts.index')->with('success', 'Updated');
}

public function destroy(Post $post)
{
    $this->authorize('delete', $post);

    foreach ($post->images as $image) {
        \Storage::disk('public')->delete($image->url);
        $image->delete();
    }

    $post->delete();

    return redirect()->route('posts.index')->with('success', 'Deleted');
}
    public function destroyImage(PostImage $image)
    {
        $this->authorize('delete', $image->post);

        Storage::disk('public')->delete($image->url);
        $image->delete();

        return back()->with('success', 'Image deleted successfully!');
    }
}