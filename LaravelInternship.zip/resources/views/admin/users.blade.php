<!DOCTYPE html>
<html>
<head>
    <title>Users Management</title>
</head>
<body>

<h2>Users Management (SuperAdmin only)</h2>

@if(session('success'))
    <p style="color:green;">{{ session('success') }}</p>
@endif

@if(session('error'))
    <p style="color:red;">{{ session('error') }}</p>
@endif

<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Change Role</th>
        </tr>
    </thead>
    <tbody>
    @foreach($users as $user)
        <tr>
            <td>{{ $user->id }}</td>
            <td>{{ $user->name }}</td>
            <td>{{ $user->email }}</td>
            <td>{{ $user->role->name ?? 'N/A' }}</td>
            <td>
                <form method="POST" action="{{ route('admin.users.role', $user->id) }}">
                    @csrf
                    <select name="role_id">
                        @foreach($roles as $role)
    @if($role->name !== 'superadmin')
        <option value="{{ $role->id }}" @if($user->role_id === $role->id) selected @endif>
            {{ ucfirst($role->name) }}
        </option>
    @endif
@endforeach</select>
                    <button type="submit">Change</button>
                </form>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

</body>
</html>