<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\AuthController;
 

Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register.form');
Route::post('/register', [AuthController::class, 'register'])->name('register');


use App\Http\Controllers\LoginController;

Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('login', [LoginController::class, 'login']);
Route::post('logout', [LoginController::class, 'logout'])->name('logout');


use Illuminate\Support\Facades\Auth;

Route::get('/home', function () {
    $user = Auth::user();
    return view('home', ['user' => $user]);
})->middleware('auth');



use App\Http\Controllers\ProfileController;

Route::middleware(['auth'])->group(function () {
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('/profile/update', [ProfileController::class, 'update'])->name('profile.update');
});

use App\Http\Controllers\EditAvatarController;

Route::middleware(['auth'])->group(function () {
    Route::get('/edit-avatar', [EditAvatarController::class, 'edit'])->name('avatar.edit');
    Route::post('/edit-avatar', [EditAvatarController::class, 'update'])->name('avatar.update');
});

use App\Http\Controllers\EditPasswordController;

Route::middleware(['auth'])->group(function () {
    Route::get('/edit-password', [EditPasswordController::class, 'edit'])->name('password.edit');
    Route::post('/edit-password', [EditPasswordController::class, 'update'])->name('password.update');
});




use App\Http\Controllers\PostController;

Route::middleware(['auth'])->group(function () {
    Route::get('/posts', [PostController::class, 'index'])->name('posts.index');
    Route::post('/posts', [PostController::class, 'store'])->name('posts.store');

    Route::get('/posts/{post}/edit', [PostController::class, 'edit'])->name('posts.edit');
    Route::put('/posts/{post}', [PostController::class, 'update'])->name('posts.update');

    Route::delete('/posts/{post}', [PostController::class, 'destroy'])->name('posts.destroy');
    Route::delete('/posts/images/{image}', [PostController::class, 'destroyImage'])->name('posts.image.destroy');
});






Route::middleware(['auth'])->group(function () {
    Route::get('/admin/users', [AuthController::class, 'index'])->name('admin.users');
    Route::post('/admin/users/{user}/role', [AuthController::class, 'updateRole'])->name('admin.users.role');
});