<!DOCTYPE html>
<html>
<head>
    <title>Users Management</title>
</head>
<body>

<h2>Users Management (SuperAdmin only)</h2>

<?php if(session('success')): ?>
    <p style="color:green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('error')): ?>
    <p style="color:red;"><?php echo e(session('error')); ?></p>
<?php endif; ?>

<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Change Role</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->role->name ?? 'N/A'); ?></td>
            <td>
                <form method="POST" action="<?php echo e(route('admin.users.role', $user->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <select name="role_id">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($role->name !== 'superadmin'): ?>
        <option value="<?php echo e($role->id); ?>" <?php if($user->role_id === $role->id): ?> selected <?php endif; ?>>
            <?php echo e(ucfirst($role->name)); ?>

        </option>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    <button type="submit">Change</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html><?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/admin/users.blade.php ENDPATH**/ ?>