<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>

<h2>Register</h2>


<form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>

    <input type="radio" name="gender" id="female" value="female">
    <label for="female">female</label>
    <input type="radio" name="gender" id="male" value="male">
    <label for="male">male</label>



    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
    <button type="submit">Register</button>
</form>

</body>
</html>
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/register.blade.php ENDPATH**/ ?>