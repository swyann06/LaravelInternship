<!DOCTYPE html>
<html>
<head>
    <title>Posts</title>
</head>
<body>

<h1>Create Post</h1>

<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="images[]" multiple required>
    <button type="submit" style="padding: 6px 12px;">Upload</button>
</form>

<hr>

<h1>All Posts</h1>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post">
        <p><strong>Post ID:</strong> <?php echo e($post->id); ?></p>

        <div>
            <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('storage/' . $img->url)); ?>" alt="Post Image">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="buttons">
            <a href="<?php echo e(route('posts.edit', $post)); ?>" class="edit-btn">Edit Post</a>

            <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="delete-btn">Delete Post</button>
            </form>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/posts/index.blade.php ENDPATH**/ ?>