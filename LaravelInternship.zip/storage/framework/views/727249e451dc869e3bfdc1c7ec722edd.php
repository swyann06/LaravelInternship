<h1>Edit Post #<?php echo e($post->id); ?></h1>

<?php if(session('success')): ?>
    <p style="color: green"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<form action="<?php echo e(route('posts.update', $post)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label>Existing Images:</label><br>

    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display:inline-block; position:relative; margin:5px;">
            <img src="<?php echo e(asset('storage/' . $image->url)); ?>" width="100">

            <button type="button"
                onclick="event.preventDefault(); document.getElementById('delete-image-<?php echo e($image->id); ?>').submit();"
                style="position:absolute; top:0; right:0; background:red; color:white;">
                X
            </button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <br><br>

    <label>Add More Images:</label><br>
    <input type="file" name="images[]" multiple>

    <br><br>
    <button type="submit">Update Post</button>
</form>

<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form id="delete-image-<?php echo e($image->id); ?>" action="<?php echo e(route('posts.image.destroy', $image)); ?>" method="POST" style="display:none;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<a href="<?php echo e(route('posts.index')); ?>">Back to All Posts</a><?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/posts/edit.blade.php ENDPATH**/ ?>