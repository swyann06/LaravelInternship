<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
</head>
<body>

<form method="POST" action="<?php echo e(route('profile.update')); ?>">
    <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="name">
        <input type="email" name="email" placeholder="email">


    <button type="submit">Update</button>
</form>

</body>
</html>
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/edit.blade.php ENDPATH**/ ?>