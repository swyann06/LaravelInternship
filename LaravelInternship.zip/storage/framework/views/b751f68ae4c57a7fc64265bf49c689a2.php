<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" required>
        <input type="password" name="password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/login.blade.php ENDPATH**/ ?>