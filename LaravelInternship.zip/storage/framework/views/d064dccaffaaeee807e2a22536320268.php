<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
<img src="<?php echo e(asset($user->avatar)); ?>" alt="User Avatar">
    <p>name: <?php echo e($user->name); ?></p>
    <p> email: <?php echo e($user->email); ?></p>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <a href="<?php echo e(route('avatar.edit')); ?>">Edit Avatar</a>
    <a href="<?php echo e(route('profile.edit')); ?>">Edit Profile</a>
    <a href="<?php echo e(route('password.edit')); ?>">Edit Password</a>

</body>
</html>
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/home.blade.php ENDPATH**/ ?>