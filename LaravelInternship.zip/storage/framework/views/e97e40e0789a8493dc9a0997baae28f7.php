   <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
</head>
<body>

<form method="POST" action="<?php echo e(route('password.update')); ?>">
    <?php echo csrf_field(); ?>
        <input type="password" name="password" placeholder="password">

    <button type="submit">Update</button>
</form>

</body>
</html>
     
        
        
        
        
        
        
        
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/editPassword.blade.php ENDPATH**/ ?>