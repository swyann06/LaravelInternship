<!DOCTYPE html>
<html>
<head>
    <title>Edit Avatar</title>
</head>
<body>

<?php if(session('success')): ?>
    <div style="color: green"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('avatar.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="avatar" accept="image/*" required>
    <button type="submit">Upload</button>
</form>

<?php if($user->avatar): ?>
    <img src="<?php echo e($user->avatar); ?>" alt="Avatar" width="100">
<?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\vladi\Desktop\LaravelInternship\resources\views/editAvatar.blade.php ENDPATH**/ ?>